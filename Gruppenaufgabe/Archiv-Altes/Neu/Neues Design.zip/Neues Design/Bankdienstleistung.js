//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//BEACHTE!!!!!!!!!!!!:////////////////////////////////////////////////////
//Wir sind eingeloggt und die Kunden auf der Linkenseite sind die von///// 
//dennen wir Rechnunge bekommen oder dennen wir eine Rechnung stellen/////
//Im Menü Home (noch nicht vorhanden) wird eine Übersicht zum eingeloggten
//gezeigt= welche Rechnungen bezahlt worden sind von andern Nutzern DEMO//
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////
var KundeLogin;

function login() {
    KundeLogin = document.getElementById("username").value;
    var logedIn = false;
    for (var i = 1; i < (Object.keys(Kunden).length); i++) {
        var t = "Kunde"+i;
        if (Kunden[t].Name == KundeLogin) {
            KundeLogin = t;
            logedIn=true;
        }
    }
    if (logedIn) {
    document.getElementById("Eingeloggt").innerHTML = "Eingeloggt als: "+Kunden[KundeLogin].Name;
    }
    else {
        document.getElementById("Eingeloggt").innerHTML = "Nicht eingeloggt. Bitte einloggen!";
        alert("Username ist dem System unbekannt.")
    }
}

function DatenEinlesen() {
    var httpRequest = new XMLHttpRequest();
    
    httpRequest.onreadystatechange = function() {
        if (this.readyState == XMLHttpRequest.DONE){                    
            var responseObject = JSON.parse(this.response);
            
            Rechnungen = responseObject.Rechnungen[0];
            //console.log(Rechnungen);
            Kunden = responseObject.Kunden[0];
            //console.log(Kunden);
            
            for (var i = 1; i < (Object.keys(Kunden).length+1); i++) {
                var nameT = "Kunde" + i;
                document.getElementById(nameT).innerHTML = Kunden[nameT].Name;
                
            }
            
        } else { }
    };
    httpRequest.open('GET', 'Daten.json', true);
    httpRequest.send(null);
}

function DatenSpeichern() {
    var xmlhttp = new XMLHttpRequest();   // new HttpRequest instance 
    xmlhttp.open("POST", "save-to-log.php");
    xmlhttp.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
    xmlhttp.send(JSON.stringify(Rechnungen));
    console.log(JSON.stringify(Rechnungen))
}

function home(){
    console.log("debug");
    document.getElementById("Ebene1").innerHTML = " <p> Das ist unere Seite </p>";
}

function getDate() {
    var heute = new Date();
    var jahr = heute.getYear()-100;
    var monat = heute.getMonth()+1;
    var tag = heute.getDate();
    return tag+"."+monat+"."+jahr;
}

function kundenauswahl(aktiverKunde){
    KundeAktiv = aktiverKunde;
    console.log("debug");
    document.getElementById("Ebene1").innerHTML = "<p id = \"pLL\">Name: "+Kunden[KundeAktiv].Name+"</p id = \"pLL\"><p id = \"pLL\">Vorname: "+Kunden[KundeAktiv].Vorname+"</p><p id = \"pLL\">IBAN: "+Kunden[KundeAktiv].IBAN+"</p><button class = \"button1\" style=\"vertical-align:middle\"onclick=\"rechnung_bezahlen()\"><a><span>Rechnung bezahlen </span></a></button><br><br><button class = \"button1\" style=\"vertical-align:middle\" onclick=\"rechung_erstellen()\"><a><span>Rechnung erstellen</span></a></button><br><br><button class = \"button1\" style=\"vertical-align:middle\"onclick=\"rechnungsübersicht()\"><a><span>Rechnungsübersicht</span></a></button>" 
    document.getElementById("Ebene2").innerHTML = "";
}
    
function rechnungsübersicht(){// Rechnungen verarbeiten in Tabelle
    console.log("debug");
    var listeRechnungen = AuswahlRechnungen(KundeAktiv);
    document.getElementById("Ebene2").innerHTML  = "<p id = \"pLL\">Rechnungsübersicht:</p><table><tr> <th>Erstellt Rechnungen</th><th>Betrag</th></tr><tr><td>Platzhalter</td><td>Platzhalter</td></tr><tr><td>Platzhalter</td><td>Platzhalter</td></tr><tr><td>Platzhalter</td><td>Platzhalter</td></tr><tr><td>Platzhalter</td><td>Platzhalter</td></tr></table>"
}


function rechung_erstellen(){//Automatische zuweisen der Felder vom aktivenKunden + API von JONAH
    console.log("debug");
    document.getElementById("Ebene2").innerHTML  = "<p id = \"pLL\">Rechnung erstellen:</p> <dl><dt>Empfänger:</dt><dd><input type=\"text\"id=\"nameField\" value="+Kunden[KundeAktiv].Vorname + Kunden[KundeAktiv].Name+" /></dd>               <dt>IBAN:</dt><dd><input type=\"text\" id=\"IBAN\" value="+Kunden[KundeAktiv].IBAN+" /></dd><dt>Betrag:</dt>                    <dd><input type=\"text\" id=\"Betrag\" value=\"0\" /></dd>                <p><a href=\"#\" onclick=\"ausgabeRechnung()\" id=\"submitLink\">Save as TXT</a></p>"                    
}

function rechnung_bezahlen(){//gestellte Rechnung in diesr Ansicht anzeigen (Verknüpfung zu gestellten Rechnungen vom aktiven Kunden)
    console.log("debug");
    var listeRechnungen = AuswahlRechnungen(KundeAktiv);
    //Rechnungen durchgeben und ausgeben: Datum, Steller, Empfänger, Betrag
    //KundeN in Namen umwandeln: Kunden[KundeN].name
    if (listeRechnungen != null) {
    if (Object.keys(listeRechnungen).length > 0) {
        for (var i = 1; i < (Object.keys(listeRechnungen).length+1); i++) {
            var Temp = "Rechnung" + i;
            //Das Objekt lässt sich jetzt so abrufen: listeRechnungen[Temp]
            //hier jetzt für jedes Objekt einen div erzeugen, beim Bezahlen das Attribut ID mitgeben!
        }
    }
    }
    else {
        console.log("Fehler: Keine Rechnungen für den Kunden vorhanden.")
    }
    document.getElementById("Ebene2").innerHTML  = "<p id = \"pLL\">Rechnung bezahlen:</p><p>Offene Rechnung:</p><div><div id=\"div1\" ondrop=\"drop(event)\" ondragover=\"allowDrop(event)\"><div class = Rechnung draggable=\"true\" ondragstart=\"drag(event)\" id=\"drag1\" width=\"88\" height=\"31\"><img src=Rechnung_schreiben-Beispiel-2.png alt= rechnung style=width:20% ><div class = container ><p>Rechnung Max Mustermann</p></div></div></div><p>Rechnung / Rechnungen bezahlen:</p><div id=\"div2\" ondrop=\"drop(event)\" ondragover=\"allowDrop(event)\"></div><br><br><button class = \"button1\" style=\"vertical-align:middle\" onclick = \"bezahlen(0)\"><span>Bezahlen</span></button></div>"
}

function bezahlen(Identifikationsnummer){//Nach Bezahlen Rechnung aus Liste streichen jedoch nicht aus Übersicht
    document.getElementById("div2").innerHTML = "";
    
    //Setzte Betrag auf 0, damit wird Rechnung bei erneutem Aufruf von AuswahlRechnungen() nicht mehr angezeigt, ist aber noch vorhanden; alter Betrag wird auf BetragAlt geschoben
    for (var i = 1; i < (Object.keys(Rechnungen).length); i++) {
        var rechnungT = "Rechnung" + i;
        if (Rechnungen[rechnungT].ID == Identifikationsnummer) {
            Rechnungen[rechnungT]["BetragAlt"] = Rechnungen[rechnungT].Betrag;
            Rechnungen[rechnungT].Betrag = 0;
            return;
        }
    }    
}

function person_hinzufügen(){//Funktion erweitern, dass wenn ein Kunde erzeugt worden ist man weiter erzeugen kann und dieser nicht überschreiben wird
    console.log("debug");
    if (Object.keys(Kunden).length > 3) {
        //es existieren mehr als die drei Initialkunden
    }
    document.getElementById("Ebene1").innerHTML  = "<p id = \"pLL\">Person hinzufügen:</p><dl><dt>Nachname:</dt><dd><input type=\"text\"id=\"lastNameField\" value=\"Mustermann\" /></dd><dt>Vorname:</dt><dd><input type=\"text\" id=\"nameField\" value=\"Max\" /></dd><dt>IBAN:</dt><dd><input type=\"text\" id=\"IBAN\" value=\"DE00000000000000000000\" /></dd><p><a href=\"#\" onclick=\"ausgabeKunde()\" id=\"submitLink\">Person anlegen</a></p>";
    document.getElementById("Ebene2").innerHTML = "";
}

function allowDrop(ev) {
    ev.preventDefault();
}

function drag(ev) {
    ev.dataTransfer.setData("text", ev.target.id);
}

function drop(ev) {
    ev.preventDefault();
    var data = ev.dataTransfer.getData("text");
    ev.target.appendChild(document.getElementById(data));
}


function ausgabeKunde(){
    var Nachname = document.getElementById("lastNameField").value;
    var VorName = document.getElementById("nameField").value;
    var Iban = document.getElementById("IBAN").value;
    console.log("Neuer Kunde ist: " + VorName + " " + Nachname + "; IBAN: " + Iban);
    var neuerKunde = "Kunde" + (Object.keys(Kunden).length+1);
    //alert(neuerKunde);
    Kunden[neuerKunde] = {Name:Nachname,Vorname:VorName,IBAN:Iban};
   
    document.getElementById("Ebene").innerHTML = "<button class = \"button\" style=\"vertical-align:middle\" onclick=\"kundenauswahl('neuerKunde')\" ><span>"+Nachname+"</span> </button>";
}

function ausgabeRechnung() {
    var empfang = "";
    for (var i = 1; i < (Object.keys(Kunden).length+1); i++) {
        var nameT = "Kunde" + i;
        //console.log(Kunden[nameT].IBAN);
        if (document.getElementById("IBAN").value == Kunden[nameT].IBAN) {
            empfang = nameT;
            console.log("gefunden");
        }
    }
    if ((Kunden[empfang].Vorname + " " + Kunden[empfang].Name) == document.getElementById("nameField").value || (Kunden[empfang].Vorname + Kunden[empfang].Name) == document.getElementById("nameField").value) {
        var neueRechnung = "Rechnung" + (Object.keys(Rechnungen).length);
        var neueID = 1;
        if (Object.keys(Rechnungen).length > 1) {
        var belegt = true;
        while (belegt) {
            neueID = neueID + 1;
            belegt = false;
            for (var i = 1; i < (Object.keys(Rechnungen).length); i++) {
            var rechnungT = "Rechnung" + i;
                if (Rechnungen[rechnungT].ID == neueID) {
                    belegt = true;
                }
            }
            //neueID = neueID + 1;
        }
        }
        var date = getDate();
        if (KundeLogin == null) {
            alert("Bitte einloggen!");
        }
        else {
            Rechnungen[neueRechnung] = {ID: neueID, Steller: KundeLogin, Empaenger: empfang, Betrag: document.getElementById("Betrag").value, Datum: date};
            console.log(Rechnungen[neueRechnung]);
        }
    }
    else {
        alert("Name Empfänger stimmt nicht mit IBAN überein.");
    }
}

function AuswahlRechnungen(KundeWahl) {
    let RechnungenKunde = {Platzhalter:"zur Initialisierung"};
    for (var i = 1; i < (Object.keys(Rechnungen).length); i++) {
        var rechnungT = "Rechnung" + i;
        if (Rechnungen[rechnungT].Empaenger == KundeWahl && Rechnungen[rechnungT].Betrag != 0) {
            if (RechnungenKunde != null) {
                var neueRechnungT = "Rechnung" + (Object.keys(RechnungenKunde).length);
            }
            else {
                var neueRechnungT = "Rechnung1";
            }
            RechnungenKunde[neueRechnungT] = Rechnungen[rechnungT];
        }
    }
    //Verarbeiten
    //console.log(RechnungenKunde);
    return RechnungenKunde;
}

 